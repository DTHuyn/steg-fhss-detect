import numpy as np
from scipy.io.wavfile import read
import scipy.signal as signal

def bandpass_filter(sig, lowcut, highcut, fs, order=6):
    nyq = 0.5 * fs
    b, a = signal.butter(order, [lowcut/nyq, highcut/nyq], btype='band')
    return signal.filtfilt(b, a, sig)

# Đọc file âm thanh
fs, stego = read("stego_audio.wav")
if stego.ndim > 1:
    stego = stego[:, 0]
stego = stego.astype(np.float32) / 32768.0

fs, original = read("original_audio.wav")
if original.ndim > 1:
    original = original[:, 0]
original = original.astype(np.float32) / 32768.0

# Lọc vùng 2000-2500 Hz
filtered_stego = bandpass_filter(stego, 2000, 2500, fs)
filtered_original = bandpass_filter(original, 2000, 2500, fs)

# Tính năng lượng
energy_stego = np.sum(filtered_stego ** 2)
energy_original = np.sum(filtered_original ** 2)
print(f"Năng lượng stego (2000-2500 Hz): {energy_stego}")
print(f"Năng lượng original (2000-2500 Hz): {energy_original}")

# Tính năng lượng từng đoạn 10ms
samples_per_segment = int(0.01 * fs)
segments_stego = [filtered_stego[i:i+samples_per_segment] for i in range(0, len(filtered_stego), samples_per_segment)]
segments_original = [filtered_original[i:i+samples_per_segment] for i in range(0, len(filtered_original), samples_per_segment)]
energy_segments_stego = [np.sum(seg ** 2) for seg in segments_stego]
energy_segments_original = [np.sum(seg ** 2) for seg in segments_original]
print(f"Trung bình năng lượng stego: {np.mean(energy_segments_stego)}")
print(f"Phương sai năng lượng stego: {np.var(energy_segments_stego)}")
print(f"Trung bình năng lượng original: {np.mean(energy_segments_original)}")
print(f"Phương sai năng lượng original: {np.var(energy_segments_original)}")