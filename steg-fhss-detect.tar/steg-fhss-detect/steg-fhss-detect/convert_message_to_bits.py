import numpy as np

# Chuyển đổi văn bản thành chuỗi bit
def text_to_bits(text):
    return ''.join(format(ord(c), '08b') for c in text)

# Đọc file message.txt và chuyển thành chuỗi bit
def convert_message_to_bits(input_file, output_file):
    # Đọc nội dung từ file message.txt
    with open(input_file, 'r', encoding='utf-8') as f:
        message = f.read().strip()
    
    # Chuyển đổi thành chuỗi bit
    bits = text_to_bits(message)
    
    # Lưu chuỗi bit vào file
    with open(output_file, 'w') as f:
        f.write(bits)
    
    # Trả về chuỗi bit và số bit
    return bits, len(bits)

# Thực thi
if __name__ == "__main__":
    input_file = "message.txt"
    output_file = "message_bits.txt"
    bits, bit_length = convert_message_to_bits(input_file, output_file)
    print(f"Chuỗi bit: {bits}")
    print(f"Kích thước thông điệp: {bit_length} bit")
    print(f"Chuỗi bit đã được lưu vào {output_file}")