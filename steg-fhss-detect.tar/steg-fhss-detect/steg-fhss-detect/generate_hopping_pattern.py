import random

# Sinh dãy nhảy tần ngẫu nhiên
def generate_hopping_pattern(bit_length, hop_range=(1, 5)):
    return [random.randint(*hop_range) for _ in range(bit_length)]

# Lưu dãy nhảy tần vào file
def save_hopping_pattern(hopping_pattern, output_file):
    with open(output_file, 'w') as f:
        f.write(' '.join(map(str, hopping_pattern)))

# Thực thi
if __name__ == "__main__":
    bit_length = int(input("Nhập số bit của thông điệp: "))
    hopping_pattern = generate_hopping_pattern(bit_length)
    output_file = "hopping_pattern.txt"
    save_hopping_pattern(hopping_pattern, output_file)
    #print(f"Dãy nhảy tần: {hopping_pattern}")
    #print(f"Độ dài dãy nhảy tần: {len(hopping_pattern)}")
    print(f"Dãy nhảy tần đã được lưu vào {output_file}")